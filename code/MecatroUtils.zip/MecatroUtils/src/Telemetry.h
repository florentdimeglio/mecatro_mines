extern unsigned int nTelemetryVariables;
extern unsigned long tickTime;

namespace mecatro{
    void sendTelemetry();
};
